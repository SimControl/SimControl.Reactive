// Copyright (c) SimControl e.U. - Wilhelm Medetz. See LICENSE.txt in the project root for more information.

using System;

namespace $rootnamespace$
{
    /// <summary></summary>
    public class $safeitemname$
    {
    }
}
